	function ex5()
     n=7.2; % the data measured by Eratosthenes
     L=800*360/n; % 
     R=L/(pi*2); % Unit conversion
     disp(L); 
     disp(R);
 end