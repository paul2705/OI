make
for ((i=1;;++i)); do
	echo testcase#$i
	./gen
	if (($?)); then
		echo Generator Error!
		break
	fi
	./release
	./force <sum.in >sum.ans
	if diff sum.out sum.ans >diff.log; then
		echo Right Output!
	else
		echo Wrong Answer!
		break
	fi
done
