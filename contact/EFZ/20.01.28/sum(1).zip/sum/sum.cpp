#include <bits/stdc++.h>

using namespace std;

// sum of integers in [1,n]
int main(){
#ifndef STDIO
	freopen("sum.in","r",stdin);
	freopen("sum.out","w",stdout);
#endif
	int n;
	scanf("%d",&n);
	printf("%d\n",(n+1)*n/2-1);
	return 0;
}

