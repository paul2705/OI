#include <bits/stdc++.h>

using namespace std;

int main(int argc,char** argv){
	/*
	// 每秒一组数据
	// 无法复现
	srand((unsigned int)time(0));
	*/

	unsigned int seed;
	
	// method 1
	freopen("seed.txt","r",stdin);
	scanf("%u",&seed);
	fclose(stdin);

	seed=(seed*19260817+233333)^seed;

	freopen("seed.txt","w",stdout);
	printf("%u\n",seed);
	fclose(stdout);

	/*
	// method 2
	seed=atoi(argv[1]);
	printf("%d\n",seed);
	*/

	srand(seed);

	freopen("sum.in","w",stdout);
	int n=rand()%1000+1;
	// 1<=n<=1000
	
	assert(1<=n&&n<=1000);
	printf("%d\n",n);

	return 0;
}
