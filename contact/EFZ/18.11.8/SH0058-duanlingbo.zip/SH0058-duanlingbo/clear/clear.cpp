#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int main(){
	freopen("clear.in","r",stdin);
	freopen("clear.out","w",stdout);
	printf("STO yyb OTZ\n");
	fclose(stdin); fclose(stdout);
	return 0;
}
